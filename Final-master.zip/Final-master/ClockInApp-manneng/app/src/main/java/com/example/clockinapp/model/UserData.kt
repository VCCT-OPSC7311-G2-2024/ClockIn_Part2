package com.example.clockinapp.model

data class UserData(
    var userName:String,
    var userMb:String
)